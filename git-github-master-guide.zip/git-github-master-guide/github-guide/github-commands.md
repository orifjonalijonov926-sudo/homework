1. GitHub nima?
Ta'rif: GitHub — Git repository'larini internetda saqlash, ulashish, ko'rib chiqish va loyihalar ustida hamkorlik qilish uchun mo'ljallangan bulutli platforma.
Vazifasi: Kodni masofaviy serverda xavfsiz saqlash, jamoaviy ishlash, issue va pull request'lar yuritish.
Amaliy misol: Brauzerda https://github.com orqali repository sahifasini ochish.

2. Git va GitHub farqi
Ta'rif: Git — kompyuterda ishlaydigan versiya nazorati dasturi; GitHub — Git repository'larini onlayn saqlash va boshqarish platformasi.
Vazifasi: Git lokal tarix va versiyalarni boshqaradi, GitHub esa ushbu repository'larni internetda joylashtirish va boshqalar bilan ulashish imkonini beradi.
Amaliy misol: Kompyuterda git commit qilib, keyin git push origin main orqali GitHub'ga yuborish.

3. GitHub account nima?
Ta'rif: GitHub account — foydalanuvchining GitHub platformasidagi shaxsiy hisobi.
Vazifasi: Repository yaratish, loyihalarni saqlash, huquqlarni boshqarish va boshqa loyihalarga hissa qo'shish.
Amaliy misol: GitHub'da ro'yxatdan o'tib, o'z profilingiz va git-github-master-guide repository'ingizni yaratish.

4. Repository nima?
Ta'rif: GitHub repository — loyiha fayllari, commitlar tarixi, branchlar, README va boshqa ma'lumotlar saqlanadigan masofaviy ombor.
Vazifasi: Loyihaning markaziy onlayn nusxasini saqlash va undagi o'zgarishlarni kuzatish.
Amaliy misol: https://github.com/USERNAME/git-github-master-guide.git manzilidagi repository.

5. Public va Private repository farqi
Ta'rif: Public repository internetdagi barcha foydalanuvchilarga ochiq ko'rinadi; Private repository esa faqat egasi va ruxsat berilgan foydalanuvchilarga ko'rinadi.
Vazifasi: Ochiq loyihalarni hammaga ulashish (Public) yoki shaxsiy/ichki loyihalarni yopiq saqlash (Private).
Amaliy misol: O'quv yoki ochiq loyihani Public, shaxsiy loyihani esa Private qilib yaratish.

6. Remote nima?
Ta'rif: Remote — lokal Git repository bilan bog'langan masofaviy repository manzili.
Vazifasi: Kompyuterdagi lokal o'zgarishlarni tashqi serverdagi repository bilan sinxronlashtirish.
Amaliy misol: Asosiy masofaviy manzil odatda origin nomi bilan ulanadi.

7. git remote add
Ta'rif: Mavjud lokal repository'ga yangi remote manzil qo'shadigan buyruq.
Vazifasi: Lokal omborni GitHub'dagi repository URL manzili bilan bog'lash.
Amaliy misol: git remote add origin https://github.com/USERNAME/REPOSITORY.git

8. git remote -v
Ta'rif: Ulangan remote repository'larning nomlari va manzillarini ko'rsatadigan buyruq.
Vazifasi: fetch va push amallari qaysi URL manzilga yo'naltirilganini tekshirish.
Amaliy misol: git remote -v

9. git push
Ta'rif: Lokal branchdagi commitlarni remote repository'ga yuboradigan buyruq.
Vazifasi: Kompyuterda qilingan o'zgarishlarni GitHub'dagi branchga yuklash (-u birinchi yuborishda upstream bog'lanishni o'rnatadi).
Amaliy misol: git push -u origin github-guide

10. git pull
Ta'rif: Remote repository'dagi yangi o'zgarishlarni yuklab olib, joriy lokal branchga birlashtiradigan buyruq.
Vazifasi: Lokal branchni masofaviy repository'dagi so'nggi holat bilan yangilash (git fetch + git merge vazifasini bajaradi).
Amaliy misol: git pull origin main

11. git clone
Ta'rif: Masofaviy repository'ning to'liq nusxasini kompyuterga ko'chirib oladigan buyruq.
Vazifasi: Remote repository asosida yangi papka va uning ichida tayyor lokal Git repository yaratish.
Amaliy misol: git clone https://github.com/USERNAME/REPOSITORY.git

12. GitHub'da branch nima?
Ta'rif: GitHub'dagi branch — repository ichidagi alohida ish yo'nalishi.
Vazifasi: Asosiy (main) branchni bevosita o'zgartirmasdan yangi bo'lim yoki vazifa ustida ishlash.
Amaliy misol: git-guide, github-guide va terminal-guide branchlarini alohida yuritish.

13. GitHub'da commit nima?
Ta'rif: Commit — repository tarixida saqlangan o'zgarishlar to'plami va uning qayd nuqtasi.
Vazifasi: Qaysi faylda qanday satrlar qo'shilgani yoki o'zgargani, kim va qachon o'zgartirganini ko'rsatish.
Amaliy misol: GitHub'da Commits bo'limiga kirib, har bir commit tafsilotini (diff) ko'rish.

14. GitHub'da faylni tahrirlash
Ta'rif: Brauzer orqali GitHub interfeysida fayl matnini bevosita o'zgartirish va commit qilish imkoniyati.
Vazifasi: Kichik tuzatish yoki qo'shimchani lokal muhitsiz ham tegishli branchga kiritish.
Amaliy misol: Repository'da faylni ochib, Edit (qalamcha) tugmasini bosish, matnni o'zgartirish va Commit changes orqali saqlash.

15. GitHub'da branchni o'chirish
Ta'rif: Keraksiz bo'lib qolgan branchni GitHub interfeysida yoki terminal orqali remote'dan o'chirish.
Vazifasi: Ish yakunlangach (odatda merge qilingandan keyin) repository'dagi branchlar ro'yxatini tartibga solish.
Amaliy misol: git push origin --delete branch-name

GitHub'da yangi repository yaratish (5 bosqich):
1. GitHub hisobiga kiring va yuqori o'ng burchakdagi + tugmasi orqali New repository bandini tanlang.
2. Repository name maydoniga nom kiriting (masalan, git-github-master-guide).
3. Ko'rinish turini tanlang (Public yoki Private) va qisqa tavsif (Description) yozing.
4. Agar lokalda README.md va .gitignore allaqachon yaratilgan bo'lsa, ularni avtomatik qo'shish kataklarini belgilamang.
5. Create repository tugmasini bosing va hosil bo'lgan HTTPS yoki SSH manzilni nusxalab oling.

Qo'shimcha savol-javoblar:
1. Savol: GitHub'da yangi repository ochayotganda lokalda README.md tayyor bo'lsa, nimaga saytda avtomatik README yaratmaslik kerak?
Javob: Aks holda remote va local tarixlar bir-biridan farq qilib, birinchi push yoki pull paytida ortiqcha ziddiyat (conflict) yoki birlashtirish muammosi chiqishi mumkin.

2. Savol: git push va git pull o'rtasidagi asosiy farq nima?
Javob: git push lokal commitlarni remote repository'ga yuboradi, git pull esa remote'dagi yangilanishlarni olib kelib lokal branchga birlashtiradi.

3. Savol: git clone bilan git init ning farqi nimada?
Javob: git init kompyuterda yangi bo'sh repository boshlaydi, git clone esa mavjud remote repository'ni tarixi bilan birga nusxalab oladi.

4. Savol: Nima uchun topshiriq davomida uchala branchni alohida push qilish kerak?
Javob: Har bir mavzuli branchdagi ish va commitlar tarixi GitHub'da alohida ko'rinishi hamda keyingi darsda merge jarayonini ko'rsatish uchun.

5. Savol: Public va Private repository qaysi holatlarda tanlanadi?
Javob: Ochiq kod yoki ko'pchilik ko'rishi kerak bo'lgan o'quv/jamoaviy ishlar uchun Public, shaxsiy yoki maxfiy fayllar uchun esa Private tanlanadi.
