1. Git nima?
Ta'rif: Git — fayllardagi o'zgarishlarni kuzatish va loyiha versiyalarini boshqarish uchun ishlatiladigan taqsimlangan versiya nazorati tizimi (DVCS).
Vazifasi: Loyiha tarixini saqlash, o'zgarishlarni qayd etish va har bir foydalanuvchida to'liq tarix nusxasini saqlash.
Qachon ishlatiladi: Har qanday dasturlash, hujjat yoki o'quv loyihasida versiyalar tarixini yuritish kerak bo'lganda.
Amaliy misol: git --version

2. Git nima uchun kerak?
Ta'rif: Git loyiha ustida ishlashni xavfsiz, tartibli va qulay qiladigan vositadir.
Vazifasi: O'zgarishlar tarixini saqlash, oldingi holatlarga qaytish, xatolar qayerda chiqqanini aniqlash, alohida branchlarda ishlash va jamoaviy hamkorlik qilish.
Qachon ishlatiladi: Kodni o'zgartirishdan oldin zahira nuqta qoldirish, eski versiyani ko'rish yoki bir nechta vazifani parallel bajarishda.
Amaliy misol: git log --oneline -n 5

3. Repository nima?
Ta'rif: Repository (ombor) — loyiha fayllari va ularning barcha o'zgarishlar tarixi (.git ma'lumotlari) saqlanadigan joy.
Vazifasi: Fayllarning joriy holati va avvalgi commitlarini bir joyda saqlash.
Qachon ishlatiladi: Lokal kompyuterda loyiha yaratilganda (local repository) yoki GitHub kabi serverda saqlanganda (remote repository).
Amaliy misol: ls -la

4. Global va Local konfiguratsiya farqi
Ta'rif: Global sozlama foydalanuvchi tizimidagi barcha loyihalar uchun amal qiladi; local sozlama esa faqat joriy repository ichida ishlaydi.
Vazifasi: Commit muallifining ismi (user.name) va elektron pochtasini (user.email) belgilash. Agar local qiymat ko'rsatilgan bo'lsa, u global qiymatdan ustun turadi.
Qachon ishlatiladi: Kompyuterda ilk bor Git sozlanganda (--global) yoki muayyan loyiha uchun boshqa ism/email ishlatish kerak bo'lganda (--local yoki bayroqsiz).
Amaliy misol: git config --global user.name "Ism Familiya" | git config --global user.email "email@example.com" | git config user.name "Lokal Ism" | git config --list

5. git init
Ta'rif: Joriy papkada yangi bo'sh Git repository ishga tushiradigan buyruq.
Vazifasi: Oddiy papkani Git kuzatadigan omborga aylantirish (ichida yashirin .git papkasi hosil bo'ladi).
Qachon ishlatiladi: Yangi loyihani kompyuterda noldan boshlayotganda.
Amaliy misol: mkdir yangi-loyiha && cd yangi-loyiha && git init

6. git status
Ta'rif: Repository'ning joriy holatini ko'rsatadigan buyruq.
Vazifasi: Qaysi fayllar yangi (untracked), o'zgargan (modified), stagingga qo'shilgan (staged) yoki hali commit qilinmaganini ko'rsatish.
Qachon ishlatiladi: Fayllarni qo'shish (git add) yoki saqlash (git commit) oldidan va keyin holatni tekshirishda.
Amaliy misol: git status | git status --ignored

7. git add
Ta'rif: Ishchi katalogdagi o'zgarishlarni staging area (index) ga o'tkazadigan buyruq.
Vazifasi: Keyingi commitga qaysi fayl yoki o'zgarishlar kirishini tanlash.
Qachon ishlatiladi: Fayl yaratilganda yoki tahrirlangandan so'ng, uni commit qilishga tayyorlashda.
Amaliy misol: git add README.md | git add git-guide/git-commands.md

8. git commit
Ta'rif: Staging area'dagi o'zgarishlarni repository tarixida yangi versiya (commit) sifatida saqlaydigan buyruq.
Vazifasi: Tanlangan o'zgarishlarni izoh (-m xabari) bilan tarixga yozib qo'yish.
Qachon ishlatiladi: Mantiqiy jihatdan tugallangan o'zgarishlar to'plamini tarixda mustahkamlashda.
Amaliy misol: git add git-guide/git-commands.md && git commit -m "Add Git commands guide"

9. git log
Ta'rif: Repository'dagi commitlar tarixini ko'rsatadigan buyruq.
Vazifasi: Commit ID (hash), muallif, sana va commit xabarlarini ko'rish.
Qachon ishlatiladi: Loyiha tarixini kuzatish, oldingi commitlarni topish yoki qisqa ro'yxatni ko'rishda.
Amaliy misol: git log | git log --oneline

10. git branch
Ta'rif: Branchlarni ko'rish, yaratish va boshqarish uchun ishlatiladigan buyruq.
Vazifasi: Mavjud branchlar ro'yxatini chiqarish yoki yangi branch yaratish.
Qachon ishlatiladi: Qaysi branchda turganingizni bilish yoki yangi ish yo'nalishi ochishda.
Amaliy misol: git branch | git branch new-feature

11. git switch
Ta'rif: Mavjud branchga o'tish yoki yangi branch yaratib unga o'tish buyrug'i.
Vazifasi: Ishchi muhitni boshqa branchga almashtirish (-c bilan yangi branch ochadi).
Qachon ishlatiladi: Boshqa branchga o'tish yoki yangi vazifa uchun yangi branch yaratishda.
Amaliy misol: git switch main | git switch -c new-feature

12. git merge
Ta'rif: Boshqa branchdagi o'zgarishlarni joriy branchga birlashtiradigan buyruq.
Vazifasi: Ikki ish yo'nalishidagi commitlarni birlashtirish (avval natija qabul qiluvchi branchga o'tiladi).
Qachon ishlatiladi: Alohida branchda tayyorlangan funksiyani asosiy branchga qo'shishda (joriy topshiriqda o'quvchi bajarmaydi).
Amaliy misol: git switch main && git merge new-feature

13. git branch -d
Ta'rif: Lokal branchni o'chiradigan buyruq.
Vazifasi: Keraksiz yoki allaqachon birlashtirilgan lokal branchni o'chirish (merge qilinmagan o'zgarish bo'lsa, Git ogohlantiradi).
Qachon ishlatiladi: Vazifa tugagach va o'zgarishlar birlashtirilgach, branchlar ro'yxatini tozalashda.
Amaliy misol: git switch main && git branch -d new-feature

Qo'shimcha savol-javoblar:
1. Savol: Git nima va u qanday ishlaydi?
Javob: Git — fayllardagi o'zgarishlarni kuzatadigan va loyiha versiyalarini boshqaradigan taqsimlangan tizim bo'lib, har bir commit orqali loyiha holatining suratini tarixda saqlaydi.

2. Savol: Nima uchun o'zgarishlarni darhol commit qilmasdan, avval git add qilinadi?
Javob: git add o'zgargan fayllar orasidan faqat kerakli qismlarni staging area'da saralab olish imkonini beradi, shunda har bir commit mazmunli va tartibli bo'ladi.

3. Savol: Global va local user.name / user.email o'rtasida qanday farq bor?
Javob: Global sozlama foydalanuvchining barcha loyihalariga taalluqli, local sozlama esa faqat joriy repository uchun ishlaydi va local qiymat mavjud bo'lsa, globaldan ustunlik qiladi.

4. Savol: git switch va git switch -c buyruqlarining farqi nimada?
Javob: git switch <branch> mavjud branchga o'tadi, git switch -c <branch> esa yangi branch yaratadi va darhol unga o'tadi.

5. Savol: git log --oneline nima uchun qulay?
Javob: U har bir commitni qisqa hash va commit xabari bilan bir qatorda chiqaradi, bu esa tarixni tez ko'zdan kechirishga yordam beradi.
