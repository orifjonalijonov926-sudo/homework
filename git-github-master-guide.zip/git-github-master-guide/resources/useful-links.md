Git rasmiy sayti va dokumentatsiyasi: https://git-scm.com/doc
GitHub Docs: https://docs.github.com
Git interaktiv o'quv qo'llanmasi: https://learngitbranching.js.org
