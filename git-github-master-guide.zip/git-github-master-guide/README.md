Git & GitHub Master Guide

Bu loyiha Git, GitHub va Terminal komandalarini o'rganish va hujjatlashtirish uchun yaratildi.

Muallif: Ism Familiya (8-sinf)

Loyiha bo'limlari:
- Git Guide (git-guide/git-commands.md) — Git asoslari va asosiy komandalar
- GitHub Guide (github-guide/github-commands.md) — GitHub platformasi va masofaviy (remote) komandalar
- Terminal Guide (terminal-guide/terminal-commands.md) — Terminal buyruqlari va ularning amaliy qo'llanilishi

Maqsad: O'rgangan komandalarimni amalda qo'llash, alohida branchlarda hujjatlashtirish va GitHub'ga yuklash.
