1. Terminal nima?
Vazifasi: Kompyuter bilan matnli buyruqlar orqali muloqot qilish imkonini beradigan dastur yoki buyruq satri interfeysi.
Qachon ishlatiladi: Fayl tizimini tez boshqarish, dasturlarni ishga tushirish va Git buyruqlarini kiritishda.
Amaliy misol: Git Bash, Terminal (macOS/Linux) yoki PowerShell oynasini ochish.

2. Terminal nima uchun kerak?
Vazifasi: Papka va fayllar yaratish, ko'chirish, o'chirish, loyiha muhitini sozlash va Git bilan samarali ishlash.
Qachon ishlatiladi: Sichqoncha bilan bir necha bosqichda bajariladigan amallarni bitta aniq buyruq bilan tez bajarishda.
Amaliy misol: Loyiha papkasiga kirib, Git holatini bir zumda tekshirish.

3. pwd — joriy joylashuvni ko'rish
Vazifasi: Terminal hozir qaysi papkada turganini to'liq yo'l (path) ko'rinishida ekranga chiqaradi.
Qachon ishlatiladi: Qaysi katalogda ishlayotganingizga ishonch hosil qilish kerak bo'lganda.
Amaliy misol: pwd

4. ls — fayllarni ko'rish
Vazifasi: Joriy papkadagi fayllar va ichki papkalar ro'yxatini ko'rsatadi (Windows PowerShell'da ls alias sifatida ishlaydi).
Qachon ishlatiladi: Papka ichida qanday fayllar borligini bilish uchun.
Amaliy misol: ls | ls -la

5. cd — papkaga kirish
Vazifasi: Ko'rsatilgan papkaga o'tadi (change directory).
Qachon ishlatiladi: Muayyan loyiha yoki ichki papka ichiga kirish kerak bo'lganda.
Amaliy misol: cd documents

6. cd .. — yuqori papkaga chiqish
Vazifasi: Joriy papkadan bitta yuqori (ota) katalogga qaytadi.
Qachon ishlatiladi: Ichki papkadan chiqib, yuqori darajadagi papkaga o'tishda.
Amaliy misol: cd ..

7. mkdir — papka yaratish
Vazifasi: Ko'rsatilgan nom bilan yangi papka (katalog) yaratadi.
Qachon ishlatiladi: Loyiha, bo'lim yoki vaqtinchalik ishchi papka ochishda.
Amaliy misol: mkdir my-folder

8. touch — fayl yaratish
Vazifasi: Git Bash, macOS va Linux'da yangi bo'sh fayl yaratadi (PowerShell'da New-Item notes.txt -ItemType File ishlatiladi).
Qachon ishlatiladi: Yangi matnli, Markdown yoki kod faylini tez yaratishda.
Amaliy misol: touch notes.txt (PowerShell: New-Item notes.txt -ItemType File)

9. cat — fayl mazmunini ko'rish
Vazifasi: Fayl ichidagi matnni o'qib, terminal oynasida chiqaradi.
Qachon ishlatiladi: Qisqa fayl (masalan, README.md yoki .gitignore) mazmunini muharrirni ochmasdan ko'rishda.
Amaliy misol: cat notes.txt

10. clear — terminalni tozalash
Vazifasi: Terminal oynasidagi oldingi buyruq va natijalarni ekrandan tozalaydi (fayllarni o'chirmaydi).
Qachon ishlatiladi: Ekran matnga to'lib ketganda yangi buyruqlarni qulay ko'rish uchun.
Amaliy misol: clear

11. cp — nusxa olish
Vazifasi: Fayl yoki papkaning nusxasini yaratadi.
Qachon ishlatiladi: Faylni o'zgartirishdan oldin uning nusxasini saqlab qo'yish yoki boshqa joyga ko'paytirishda.
Amaliy misol: cp notes.txt notes-copy.txt

12. mv — ko'chirish yoki nomini o'zgartirish
Vazifasi: Fayl yoki papkani boshqa joyga ko'chiradi yoki uning nomini o'zgartiradi.
Qachon ishlatiladi: Fayl nomini to'g'irlash yoki uni boshqa papkaga o'tkazishda.
Amaliy misol: mv old.txt new.txt

13. rm — fayl o'chirish
Vazifasi: Ko'rsatilgan faylni o'chiradi. Faqat o'zingiz yaratgan mashq/sinov fayllarida ehtiyotkorlik bilan ishlating (rm -rf kabi xavfli buyruqlarni bu topshiriqda ishlatmang).
Qachon ishlatiladi: Keraksiz bo'lgan sinov faylini o'chirishda.
Amaliy misol: rm notes-copy.txt

14. git init — repository yaratish
Vazifasi: Joriy papkada yangi lokal Git repository ishga tushiradi.
Qachon ishlatiladi: Yangi papkani Git versiya nazoratiga ulashda.
Amaliy misol: mkdir my-project && cd my-project && git init

15. git status — Git holatini tekshirish
Vazifasi: Repository'dagi yangi, o'zgargan va stagingga qo'shilgan fayllar holatini ko'rsatadi.
Qachon ishlatiladi: O'zgarishlarni tekshirish, commit oldidan nazorat qilish yoki .gitignore ishlashini ko'rishda.
Amaliy misol: git status
